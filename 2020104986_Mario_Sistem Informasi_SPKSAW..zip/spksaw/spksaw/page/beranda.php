<!-- judul -->
<div class="panel">
    <div class="panel-middle" style="background-color:#6ebd6d"id="judul">
        <img src="asset/image/LOGO1.PNG" width="230" height="200">
        <div id="judul-text">
            <h2 style="color:white"> HOME </h2>
            <p style="color:white"> Halaman utama </p>
        </div>
    </div>
</div>
<!-- judul -->
<div class="panel">
    <div class="panel-middle text-center">
        <h1>
            WEBSITE SISTEM PENDUKUNG KEPUTUSAN PEMILIHAN SUPPLIER SERABUT KELAPA <br><br><p class="text-green"> SIMPLE ADDITIVE WEIGHTING</p>
        </h1>
    </div>
    <div class="panel-bottom"></div>
</div>
