
<button class="btn btn-second" id="hidden"><i class="fa fa-list text-white"></i></button>
<ul class="nav">
    <li><a href="./?page=beranda">HOME</a></li>
    <li><a href="./?page=barang">ITEM</a></li>
    <li><a href="./?page=supplier">SUPPLIER</a></li>
    <li><a href="./?page=kriteria">CRITERIA</a></li>
    <li><a href="./?page=subkriteria">SUB CRITERIA</a></li>
    <li><a href="./?page=bobot">SCORING</a></li>
    <li><a href="./?page=penilaian">PROCESS</a></li>
    <li><a href="./?page=hasil">RESULT</a></li>
    <li><a href="./logout.php" id="out">LOG OUT</a></li>
</ul>
